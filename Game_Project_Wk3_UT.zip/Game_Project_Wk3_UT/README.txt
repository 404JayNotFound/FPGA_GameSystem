HDL Game Platform – Basys3 FPGA Project

This repository contains the Week 3 progress for the HDL Game Platform project. 
The goal of the project is to design a modular FPGA-based hardware system on the Basys3 
board that can act as a platform for running simple video games (e.g., Tetris). 
The project uses Verilog, Vivado, and several Digilent PMOD peripherals.

------------------------------------------------------------
Project Overview
------------------------------------------------------------

The system is designed as a collection of hardware subsystems which work together:

1. VGA Display Subsystem
   Generates VGA timing signals and outputs pixel data to a monitor.
   Uses a simple test pattern for Week 3.

2. Input Subsystem
   Includes the 4×4 keypad (Pmod KYPD).
   A keypad decoder module scans keys and outputs a 4-bit key code.

3. Flash Memory Subsystem
   Supports configuration storage using Pmod SF3.
   This module is planned but not implemented yet (scheduled for Week 4–5).

4. Joystick Subsystem
   Supports directional and button input using Pmod JSTK2.
   SPI module planned but not implemented yet.

5. System Controller
   Central state machine that manages system behaviour.
   For Week 3 it transitions through simple states and responds to keypad input.

6. Top-Level Integration
   Connects all subsystems together and maps signals to the Basys3 pins.

------------------------------------------------------------
Current Status (End of Week 3)
------------------------------------------------------------

Working modules:

- vga_sync.v – Generates VGA timing for 640×480 @ 60 Hz
- vga_test.v – Displays a simple colour output using switch values
- decoder.v – Keypad scanner producing a 4-bit key code
- system_controller.v – Simple FSM using keypad input
- top.v – Connects VGA, keypad, and system controller
- constraints.xdc – Clock, reset, VGA pins + placeholders for PMODs

------------------------------------------------------------
How to Build in Vivado
------------------------------------------------------------

1. Open Vivado → Create New Project
2. Add all .v files under "Add Design Sources"
3. Add constraints.xdc under "Add or Create Constraints"
4. Set top.v as the top module
5. Select Basys3 as the target board
6. Run Synthesis, Implementation, and Generate Bitstream
7. Connect VGA and Pmod KYPD for testing

------------------------------------------------------------
Planned Work (Week 4+)
------------------------------------------------------------

- Joystick SPI module integration
- Flash SPI controller implementation
- Expanded system controller FSM
- Tilemap-based VGA rendering
- Begin simulation and waveform verification
- Documentation for PMOD wiring and pin mapping

------------------------------------------------------------
Project Structure
------------------------------------------------------------

FPGA_GamePlatform/
│
├── src/
│   ├── top.v
│   ├── system_controller.v
│   ├── vga/
│   │   ├── vga_sync.v
│   │   └── vga_test.v
│   ├── input/
│   │   └── decoder.v
│   ├── flash/        (placeholder)
│   └── joystick/     (placeholder)
│
├── constraints/
│   └── constraints.xdc
│
├── docs/
│   └── Week3_Report.docx
│
└── README.txt

------------------------------------------------------------
Contributors
------------------------------------------------------------

- Member A – VGA subsystem
- Member B – Keypad decoder, SPI input modules, flash subsystem
- Member C – Top-level integration, FSM controller, constraints, documentation
